## ----eval=FALSE----------------------------------------------------------
#  mydata <- airquality[1:2,]
#  y <- reshape2::melt(data = mydata, id = c("Month", "Day"))
#  toJSON(y)

