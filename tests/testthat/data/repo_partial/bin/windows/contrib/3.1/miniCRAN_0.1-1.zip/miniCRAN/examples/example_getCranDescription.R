\dontrun{
getCranDescription(c("igraph", "ggplot2", "XML"), 
  repos=c(CRAN="http://cran.revolutionanalytics.com")
)
}
