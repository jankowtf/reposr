## ----, echo = FALSE, message = FALSE-------------------------------------
knitr::opts_chunk$set(
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ----, eval = FALSE------------------------------------------------------
#  #' @include class-a.r
#  setClass("B", contains = "A")

