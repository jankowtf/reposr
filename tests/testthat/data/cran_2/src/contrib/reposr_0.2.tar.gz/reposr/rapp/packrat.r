packrat::init()
