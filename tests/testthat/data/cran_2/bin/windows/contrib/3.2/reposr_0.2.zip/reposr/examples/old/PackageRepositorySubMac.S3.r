PackageRepositorySubMac.S3()
PackageRepositorySubMac.S3(path = "a/b/c")

PackageRepositorySubMac.S3(.x = c(TRUE, FALSE))
