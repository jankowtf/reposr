PackageRepositorySubGeneric.S3()
PackageRepositorySubGeneric.S3(path = "a/b/c")

PackageRepositorySubGeneric.S3(.x = c(TRUE, FALSE))
