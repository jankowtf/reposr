PackageRepositorySubSource.S3()
PackageRepositorySubSource.S3(path = "a/b/c")

PackageRepositorySubSource.S3(.x = c(TRUE, FALSE))
