#' @references \url{http://github.com/rappster/reposr}
