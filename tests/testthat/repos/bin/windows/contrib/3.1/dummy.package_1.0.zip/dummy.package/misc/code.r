devtools::build(path = "Q:/home/wsp/rapp2/rapp.core.repos/tests/testthat/repos/src/contrib")
devtools::build(path = "Q:/home/wsp/rapp2/rapp.core.repos/tests/testthat/repos/bin/windows/contrib/3.1")