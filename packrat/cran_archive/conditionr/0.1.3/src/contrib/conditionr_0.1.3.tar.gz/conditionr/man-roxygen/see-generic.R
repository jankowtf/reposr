#' See generic \link[examplr]{getBinaryExampleStatus}
