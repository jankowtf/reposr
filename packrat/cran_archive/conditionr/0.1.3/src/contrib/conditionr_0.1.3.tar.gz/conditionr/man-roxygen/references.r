#' @references \url{http://github.com/Rappster/conditionr}
