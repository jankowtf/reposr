# CHANGES IN VERSION 0.1.3

## NEW FEATURES

## BUG FIXES

## MAJOR CHANGES

## MINOR CHANGES

## MISC

-----

# CHANGES IN VERSION 0.1.3

## NEW FEATURES

## BUG FIXES

## MAJOR CHANGES

## MINOR CHANGES

## MISC

-----

# CHANGES IN conditionr VERSION 0.1.1.2

## NEW FEATURES

## BUG FIXES

## MAJOR CHANGES

## MINOR CHANGES

## MISC

- tried out interaction with `rapp.core.rte` (v0.1.0.2)

-----

# CHANGES IN conditionr VERSION 0.1.1.1

## NEW FEATURES

## BUG FIXES

## MAJOR CHANGES

## MINOR CHANGES

## MISC

- new patch version in order to comply repository conventions

-----

# CHANGES IN conditionr VERSION 0.1.1

Frozen: yes
Corresponds to patch version: `v0.1.0.3'

## NEW FEATURES

## BUG FIXES

## MAJOR CHANGES

## MINOR CHANGES

-----

# CHANGES IN conditionr VERSION 0.1.0.3

## NEW FEATURES

## BUG FIXES

## MAJOR CHANGES

## MINOR CHANGES
