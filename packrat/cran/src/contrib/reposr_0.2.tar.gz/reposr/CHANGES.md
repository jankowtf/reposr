# Version 0.2
- Manual bump

# Version 0.1.4
 - Cleanup commit

----------

# Version 0.1.3
 - Cleanup commit for git-flow
 - On branch master Ensured 'rapp.core.condition::signalCondition()'

----------


