PackageRepositorySubWindows.S3()
PackageRepositorySubWindows.S3(path = "a/b/c")

PackageRepositorySubWindows.S3(.x = c(TRUE, FALSE))
