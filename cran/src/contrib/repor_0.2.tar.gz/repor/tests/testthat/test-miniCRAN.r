rversion <- paste(
  R.version$major, 
  unlist(strsplit(R.version$minor, split="\\."))[2], sep="."
)

withConditionalWorkingDirectory <- function(code) {
  wd <- getwd()
  if (!length(grep("/tests/testthat$", wd))) {
    setwd("tests/testthat")
  }
  on.exit(setwd(wd))
  force(code)
}

# install.packages("miniCRAN")
require("miniCRAN")
pkgs <- c("chron")
pkgDep(pkgs) 
p <- makeDepGraph(pkgs, enhances = TRUE)
# ?plot.pkgDepGraph 
plot(p)


repo <- PackageRepository$new()
repo$ensure()
repo$buildInto()
repo$show()

repo$register(name = "LCRAN")

getOption("repos")
pkgs <- c("repor", "chron")
pkgs <- "repor"
pkgDep(pkgs) 

p <- makeDepGraph(pkgs, enhances = TRUE)
plot(p)

##------------------------------------------------------------------------------
context("PackageRepository/constructor")
##------------------------------------------------------------------------------

test_that("PackageRepository/constructor/bare", {

  expect_is(res <- PackageRepository$new(), "PackageRepository")
  expect_true(!is.null(res$root))
  expect_true(!is.null(res$type))
  expect_identical(res$type, "fs")
  
})

